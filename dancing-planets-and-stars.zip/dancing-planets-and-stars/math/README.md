# Math Generator

Generates Stake Engine static outputs with base spins, free spins, buy features, Earth multipliers, and a 5000× cap.

Run:

```bash
pip install -r requirements.txt
python generate_static_results.py --spins 200000 --seed 1337
```
