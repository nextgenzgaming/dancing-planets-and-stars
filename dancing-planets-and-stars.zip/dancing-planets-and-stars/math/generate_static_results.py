#!/usr/bin/env python3
import json, random, argparse, csv, io, time
from pathlib import Path
import zstandard as zstd

ROOT = Path(__file__).resolve().parents[1]
CFG_DIR = ROOT / "math" / "config"
OUT_DIR = ROOT / "library" / "publish_files"
OUT_DIR.mkdir(parents=True, exist_ok=True)

def load_cfg():
    with open(CFG_DIR/"paylines.json") as f: paylines = json.load(f)["paylines"]
    with open(CFG_DIR/"paytable.json") as f: paytable = json.load(f)
    with open(CFG_DIR/"reels.json") as f: reels = json.load(f)["reels"]
    with open(CFG_DIR/"buy_config.json") as f: buy = json.load(f)
    return paylines, paytable, reels, buy

def spin_board(reels):
    board = []
    for strip in reels:
        idx = random.randrange(len(strip))
        col = [strip[(idx+i) % len(strip)] for i in range(3)]
        board.append(col)
    return board

def line_win_for_symbol(board, line, sym, paytable):
    count = 0
    for col, row in enumerate(line):
        s = board[col][row]
        if s == sym or (s == "WILD" and sym != "WILD"):
            count += 1
        else:
            break
    if count >= 3:
        pays = paytable[sym]
        return pays[count-3]
    return 0.0

def total_line_wins(board, paylines, paytable):
    tot = 0.0
    for line in paylines:
        best = 0.0
        for sym in paytable.keys():
            if sym in ("WILD","SCATTER","EARTH10","EARTH20","EARTH50"):
                continue
            best = max(best, line_win_for_symbol(board, line, sym, paytable))
        tot += best
    return tot

def count_scatters(board):
    return sum(1 for c in board for s in c if s == "SCATTER")

def earth_multiplier(board):
    mult = 1
    for c in board:
        for s in c:
            if s == "EARTH10": mult = max(mult, 10)
            elif s == "EARTH20": mult = max(mult, 20)
            elif s == "EARTH50": mult = max(mult, 50)
    return mult

def clamp_payout(payout, max_mult):
    return min(payout, max_mult)

def simulate_spin(reels, paylines, paytable, cfg):
    board = spin_board(reels)
    base = total_line_wins(board, paylines, paytable)
    mult = earth_multiplier(board)
    payout = base * mult
    payout = clamp_payout(payout, cfg["max_win_mult"])
    scat = count_scatters(board)
    return board, payout, scat, mult

def gamble_spins(n, chance_percent):
    return (n + 5, True) if random.randrange(100) < chance_percent else (n, False)

def simulate_free_spins(n_spins, reels, paylines, paytable, cfg):
    total = 0.0
    for _ in range(n_spins):
        _, p, _, _ = simulate_spin(reels, paylines, paytable, cfg)
        total += p
    total = clamp_payout(total, cfg["max_win_mult"])
    return total

def main(spins, seed):
    random.seed(seed)
    paylines, paytable, reels, cfg = load_cfg()
    buy_modes = cfg["buy_modes"]
    gamble_chance = cfg["gamble_upgrade_chance_percent"]

    events = io.BytesIO()
    compressor = zstd.ZstdCompressor(level=10).stream_writer(events)

    rows = []

    for sim in range(spins):
        board, payout, scat, mult = simulate_spin(reels, paylines, paytable, cfg)

        event = {"sim_number": f"{sim}", "events":[{"type":"base","board":board},{"type":"eval","payout_x":round(payout,4)}]}
        compressor.write((json.dumps(event,separators=(',',':'))+"\n").encode())
        rows.append((f"{sim}", payout))

        if scat >= 4:
            base_spins = 10 if scat == 4 else 15
            final_spins, upgraded = gamble_spins(base_spins, gamble_chance)
            total = simulate_free_spins(final_spins, reels, paylines, paytable, cfg)
            event = {"sim_number": f"{sim}_bonus", "events":[
                {"type":"bonus_trigger","scatter_count":scat,"base_spins":base_spins,"final_spins":final_spins,"upgraded":upgraded},
                {"type":"eval","payout_x":round(total,4)}
            ]}
            compressor.write((json.dumps(event,separators=(',',':'))+"\n").encode())
            rows.append((f"{sim}_bonus", total))

        for mode_name, spec in buy_modes.items():
            base_spins = spec["spins"]
            final_spins, upgraded = gamble_spins(base_spins, gamble_chance)
            total = simulate_free_spins(final_spins, reels, paylines, paytable, cfg)
            payout_x = clamp_payout(total - spec["cost_mult"], cfg["max_win_mult"])
            event = {"sim_number": f"{sim}_{mode_name}", "events":[
                {"type":"buy","mode":mode_name,"base_spins":base_spins,"final_spins":final_spins,"upgraded":upgraded,"cost_mult":spec["cost_mult"]},
                {"type":"eval","payout_x":round(payout_x,4)}
            ]}
            compressor.write((json.dumps(event,separators=(',',':'))+"\n").encode())
            rows.append((f"{sim}_{mode_name}", payout_x))

    compressor.flush(zstd.FLUSH_FRAME)
    (OUT_DIR/"results.zst").write_bytes(events.getvalue())

    N = len(rows)
    weight = 1.0/N if N else 0.0
    with open(OUT_DIR/"lookup.csv","w",newline="") as f:
        w = json.dumps
        writer = csv.writer(f)
        writer.writerow(["sim_number","weight","payout_mult"])
        for sn, px in rows:
            writer.writerow([sn, f"{weight:.12f}", round(px,6)])

    base_only = [px for sn, px in rows if "_" not in sn]
    rtp_est = (sum(base_only)/len(base_only))*100 if base_only else 0.0
    idx = {"name":"Dancing Planets and Stars","version":"1.0.0","format":"stake_static_v1","created_at":int(time.time()),"generated_spins":spins,"base_rtp_estimate_percent":round(rtp_est,2)}
    with open(OUT_DIR/"index.json","w") as f: json.dump(idx,f,indent=2)

    print(f"Generated {spins} spins. Base RTP estimate: {rtp_est:.2f}%")
    print(f"Wrote bundle to: {OUT_DIR}")

if __name__ == "__main__":
    import sys
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--spins", type=int, default=200000)
    ap.add_argument("--seed", type=int, default=1337)
    args = ap.parse_args()
    main(args.spins, args.seed)
