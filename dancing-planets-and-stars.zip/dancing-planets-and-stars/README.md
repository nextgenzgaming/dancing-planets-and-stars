# 🌌 Dancing Planets and Stars — Stake Engine Slot

A production-ready starter for a Stake Engine static-integration slot. It includes:
- Math generator that emits **results.zst**, **lookup.csv**, **index.json**
- Base game (5×3, 20 lines), **4+ Scatter** free-spins, **Gamble** (+5 spins on 25%),
  **Buy features** (Free Spins, Super Free Spins), **Earth multipliers** (10×/20×/50×),
  and a **Max Win cap = 5000×**
- Minimal **React + Vite** frontend with demo buttons to call `/play` and buy modes

> Rename, reskin, and tune; this is meant to be a clean template.

---

## Quick Start

### 1) Math bundle
```bash
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r math/requirements.txt
python math/generate_static_results.py --spins 200000 --seed 1337
```
Outputs:
```
library/publish_files/
  ├─ results.zst
  ├─ lookup.csv
  └─ index.json
```

### 2) Frontend
```bash
cd frontend
npm ci
echo "VITE_RGS_BASE_URL=https://<from-acp>" > .env
echo "VITE_GAME_ID=dancing_planets" >> .env
echo "VITE_API_TOKEN=<from-acp>" >> .env
npm run build
```
Upload `frontend/dist/` to ACP for the game's frontend.

### 3) Upload to Stake Engine
1. Create **New Game** in ACP → name: *Dancing Planets and Stars*.
2. Upload **math bundle** from `library/publish_files/`.
3. Upload **frontend** from `frontend/dist/`.
4. Verify in Sandbox, then publish.

---

## Game Spec
- **Grid:** 5×3, **Paylines:** 20 fixed
- **Symbols:** Low (T, J, Q, K, A), Premiums (G1–G4), **WILD**, **SCATTER**, **EARTH10/EARTH20/EARTH50**
- **Bonus:** 4 scatters → 10 free spins; 5 scatters → 15 free spins
- **Gamble:** 25% chance to +5 spins on entry (both natural and buys)
- **Buy Features:** Free Spins (10) and Super Free Spins (15); costs are tuned to target ≈97% RTP for buy mode
- **Max Win:** 5000× (cap applied to every evaluation)
- **Target RTP:** Base ≈90% (tune paytable & reels); Buy ≈97% (tune `cost_mult`)

---

## File Map
```
.
├─ math/
│  ├─ config/
│  │  ├─ paylines.json
│  │  ├─ paytable.json
│  │  ├─ reels.json
│  │  └─ buy_config.json
│  ├─ generate_static_results.py
│  ├─ requirements.txt
│  └─ README.md
├─ library/
│  └─ publish_files/        # generated
├─ frontend/                # React + Vite
│  ├─ index.html
│  ├─ package.json
│  ├─ vite.config.ts
│  ├─ tsconfig.json
│  └─ src/
│     ├─ main.tsx
│     ├─ App.tsx
│     └─ api.ts
└─ README.md
```
