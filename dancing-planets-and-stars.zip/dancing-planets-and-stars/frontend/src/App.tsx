import React, { useState } from 'react'
import { playRound } from './api'
export default function App(){
  const [bet, setBet] = useState(100)
  const [busy, setBusy] = useState(false)
  const [resp, setResp] = useState<any>(null)
  async function doPlay(mode?: 'free_spins'|'super_free_spins'){
    setBusy(true)
    try{ const r = await playRound(bet, mode); setResp(r) }
    catch(e:any){ alert(e.message || 'Error') }
    finally{ setBusy(false) }
  }
  return (<main style={{maxWidth:720, margin:'40px auto', fontFamily:'system-ui,Segoe UI,Roboto,Helvetica,Arial,sans-serif'}}>
    <h1>🌌 Dancing Planets and Stars</h1>
    <p>Demo frontend wired for Stake Engine RGS. Fill <code>.env</code> and build.</p>
    <div style={{display:'flex', gap:12, alignItems:'center'}}>
      <label>Bet (¢): <input type='number' min={1} step={1} value={bet} onChange={e=>setBet(parseInt(e.target.value||'0',10))}/></label>
      <button disabled={busy} onClick={()=>doPlay()}>Spin</button>
      <button disabled={busy} onClick={()=>doPlay('free_spins')}>Buy Free Spins</button>
      <button disabled={busy} onClick={()=>doPlay('super_free_spins')}>Buy Super Free Spins</button>
    </div>
    <h3>Last /play response</h3>
    <pre style={{background:'#111', color:'#eee', padding:12, borderRadius:8, overflow:'auto', maxHeight:280}}>{resp ? JSON.stringify(resp,null,2) : null}</pre>
  </main>)}
