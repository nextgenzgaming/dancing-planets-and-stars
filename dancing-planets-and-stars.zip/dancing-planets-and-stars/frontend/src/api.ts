const BASE_URL = import.meta.env.VITE_RGS_BASE_URL || 'https://rgs.stake.example';
const GAME_ID = import.meta.env.VITE_GAME_ID || 'dancing_planets';
const TOKEN = import.meta.env.VITE_API_TOKEN || '';
export async function playRound(betCents: number, mode?: 'free_spins'|'super_free_spins') {
  const payload: any = { game_id: GAME_ID, bet: betCents };
  if (mode) payload.mode = mode;
  const res = await fetch(`${BASE_URL}/play`, {
    method: 'POST',
    headers: { 'Content-Type':'application/json', 'Authorization': `Bearer ${TOKEN}` },
    body: JSON.stringify(payload)
  });
  if (!res.ok) throw new Error('Play failed');
  return res.json();
}
